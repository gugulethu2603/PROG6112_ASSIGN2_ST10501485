/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author 50324
 */
public class RescueCaseTest {
    
    public RescueCaseTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getCaseId method, of class RescueCase.
     */
    @Test
    public void testGetCaseId() {
        System.out.println("getCaseId");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getCaseId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAnimalName method, of class RescueCase.
     */
    @Test
    public void testGetAnimalName() {
        System.out.println("getAnimalName");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getAnimalName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSpecies method, of class RescueCase.
     */
    @Test
    public void testGetSpecies() {
        System.out.println("getSpecies");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getSpecies();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueLocation method, of class RescueCase.
     */
    @Test
    public void testGetRescueLocation() {
        System.out.println("getRescueLocation");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getRescueLocation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAssignedRanger method, of class RescueCase.
     */
    @Test
    public void testGetAssignedRanger() {
        System.out.println("getAssignedRanger");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getAssignedRanger();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueDays method, of class RescueCase.
     */
    @Test
    public void testGetRescueDays() {
        System.out.println("getRescueDays");
        RescueCase instance = null;
        int expResult = 0;
        int result = instance.getRescueDays();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDailyCareCost method, of class RescueCase.
     */
    @Test
    public void testGetDailyCareCost() {
        System.out.println("getDailyCareCost");
        RescueCase instance = null;
        double expResult = 0.0;
        double result = instance.getDailyCareCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCurrentStatus method, of class RescueCase.
     */
    @Test
    public void testGetCurrentStatus() {
        System.out.println("getCurrentStatus");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getCurrentStatus();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCurrentStatus method, of class RescueCase.
     */
    @Test
    public void testSetCurrentStatus() {
        System.out.println("setCurrentStatus");
        String currentStatus = "";
        RescueCase instance = null;
        instance.setCurrentStatus(currentStatus);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBaseCareCost method, of class RescueCase.
     */
    @Test
    public void testGetBaseCareCost() {
        System.out.println("getBaseCareCost");
        RescueCase instance = null;
        double expResult = 0.0;
        double result = instance.getBaseCareCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displaySpecificInfo method, of class RescueCase.
     */
    @Test
    public void testDisplaySpecificInfo() {
        System.out.println("displaySpecificInfo");
        RescueCase instance = null;
        instance.displaySpecificInfo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class RescueCaseImpl extends RescueCase {

        public RescueCaseImpl() {
            super("", "", "", "", "", 0, 0.0, "");
        }

        public void displaySpecificInfo() {
        }
    }

    public class RescueCaseImpl extends RescueCase {

        public RescueCaseImpl() {
            super("", "", "", "", "", 0, 0.0, "");
        }

        public void displaySpecificInfo() {
        }
    }

    public class RescueCaseImpl extends RescueCase {

        public RescueCaseImpl() {
            super("", "", "", "", "", 0, 0.0, "");
        }

        public void displaySpecificInfo() {
        }
    }
    
}
