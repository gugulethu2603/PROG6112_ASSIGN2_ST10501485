/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author 50324
 */
public class RescueOperationsTest {
    
    public RescueOperationsTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of calculateTotalCost method, of class RescueOperations.
     */
    @Test
    public void testCalculateTotalCost() {
        System.out.println("calculateTotalCost");
        RescueOperations instance = new RescueOperationsImpl();
        double expResult = 0.0;
        double result = instance.calculateTotalCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of determinePriority method, of class RescueOperations.
     */
    @Test
    public void testDeterminePriority() {
        System.out.println("determinePriority");
        RescueOperations instance = new RescueOperationsImpl();
        String expResult = "";
        String result = instance.determinePriority();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueType method, of class RescueOperations.
     */
    @Test
    public void testGetRescueType() {
        System.out.println("getRescueType");
        RescueOperations instance = new RescueOperationsImpl();
        String expResult = "";
        String result = instance.getRescueType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class RescueOperationsImpl implements RescueOperations {

        public double calculateTotalCost() {
            return 0.0;
        }

        public String determinePriority() {
            return "";
        }

        public String getRescueType() {
            return "";
        }
    }

    public class RescueOperationsImpl implements RescueOperations {

        public double calculateTotalCost() {
            return 0.0;
        }

        public String determinePriority() {
            return "";
        }

        public String getRescueType() {
            return "";
        }
    }

    public class RescueOperationsImpl implements RescueOperations {

        public double calculateTotalCost() {
            return 0.0;
        }

        public String determinePriority() {
            return "";
        }

        public String getRescueType() {
            return "";
        }
    }
    
}
