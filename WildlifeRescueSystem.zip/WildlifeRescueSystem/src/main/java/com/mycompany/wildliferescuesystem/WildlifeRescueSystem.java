/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.wildliferescuesystem;

import java.util.ArrayList;
import java.util.Scanner;


//  THE CONTRACT INTERFACE

interface RescueOperations {
    double calculateTotalCost();
    String determinePriority();
    String getRescueType();
}


// THE ABSTRACT BASE CLASS

abstract class RescueCase implements RescueOperations {
    private String caseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int rescueDays;
    private double dailyCareCost;
    private String currentStatus;

    public RescueCase(String caseId, String animalName, String species, String rescueLocation, 
                      String assignedRanger, int rescueDays, double dailyCareCost, String currentStatus) {
        this.caseId = caseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.currentStatus = currentStatus;
    }

    public String getCaseId() { return caseId; }
    public String getAnimalName() { return animalName; }
    public String getSpecies() { return species; }
    public String getRescueLocation() { return rescueLocation; }
    public String getAssignedRanger() { return assignedRanger; }
    public int getRescueDays() { return rescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public String getCurrentStatus() { return currentStatus; }
    public void setCurrentStatus(String currentStatus) { this.currentStatus = currentStatus; }

    protected double getBaseCareCost() {
        return rescueDays * dailyCareCost;
    }

    public abstract void displaySpecificInfo();
}


// INJURED ANIMAL SUBCLASS

class InjuredRescue extends RescueCase {
    private String injuryDescription;
    private double vetTreatmentCost;
    private boolean surgeryRequired;

    public InjuredRescue(String caseId, String animalName, String species, String rescueLocation, 
                         String assignedRanger, int rescueDays, double dailyCareCost, String currentStatus,
                         String injuryDescription, double vetTreatmentCost, boolean surgeryRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost, currentStatus);
        this.injuryDescription = injuryDescription;
        this.vetTreatmentCost = vetTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }
//POLYMORPHISM: OVERRIDING THE COST CLCULATION RULE FOR INJURIES
    @Override
    public double calculateTotalCost() {
        double cost = getBaseCareCost() + vetTreatmentCost;
        if (surgeryRequired) cost += 5000.00;
        return cost;
    }
//OVERRIDING PRIORITY LOGIC BASED ON MEDICAL URGENCY
    @Override
    public String determinePriority() {
        return surgeryRequired ? "Critical" : "Medium";
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }
// DISPLAY IMPLEMENTATION SPECIFIC TO MEDICAL CONDITIONS
    @Override
    public void displaySpecificInfo() {
        System.out.println("Injury Description : " + injuryDescription);
        System.out.println("Vet Treatment Cost : R" + vetTreatmentCost);
        System.out.println("Surgery Required   : " + (surgeryRequired ? "Yes" : "No"));
    }
}


// ORPHANED ANIMAL SUBCLASS

class OrphanedRescue extends RescueCase {
    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedRescue(String caseId, String animalName, String species, String rescueLocation, 
                          String assignedRanger, int rescueDays, double dailyCareCost, String currentStatus,
                          int estimatedAgeMonths, double feedingCost, boolean fosterCareRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost, currentStatus);
        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public double calculateTotalCost() {
        double cost = getBaseCareCost() + feedingCost;
        if (fosterCareRequired) cost += 2500.00;
        return cost;
    }

    @Override
    public String determinePriority() {
        return (estimatedAgeMonths < 3 || fosterCareRequired) ? "High" : "Medium";
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    public void displaySpecificInfo() {
        System.out.println("Estimated Age      : " + estimatedAgeMonths + " months");
        System.out.println("Feeding Cost       : R" + feedingCost);
        System.out.println("Foster Care Needed : " + (fosterCareRequired ? "Yes" : "No"));
    }
}

//ENDANGERED SPECIES SUBCLASS

class EndangeredRescue extends RescueCase {
    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredRescue(String caseId, String animalName, String species, String rescueLocation, 
                            String assignedRanger, int rescueDays, double dailyCareCost, String currentStatus,
                            String conservationClassification, double securityCost, boolean specialistTeamRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost, currentStatus);
        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public double calculateTotalCost() {
        double cost = getBaseCareCost() + securityCost;
        if (specialistTeamRequired) cost += 8000.00;
        return cost;
    }

    @Override
    public String determinePriority() {
        return "High";
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public void displaySpecificInfo() {
        System.out.println("Classification     : " + conservationClassification);
        System.out.println("Security Cost      : R" + securityCost);
        System.out.println("Specialist Team    : " + (specialistTeamRequired ? "Yes" : "No"));
    }
}

//  MAIN SYSTEM (MATCHES FILE NAME)

   
public class WildlifeRescueSystem {
    private static ArrayList<RescueCase> cases = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        cases.add(new InjuredRescue("WR101", "Tembo", "African Elephant", "Kruger", "Ranger John", 10, 500, "Rescue in Progress", "Leg fracture", 10500, true));
        cases.add(new OrphanedRescue("WR102", "Siku", "White Rhino", "Pilanesberg", "Ranger Sam", 15, 300, "Under Observation", 4, 4500, false));
//MENU DISPLAY LOOP THAT RUNS UNTIL EXITED BY THE USER
        while (true) {
            System.out.println("\n================================================");
            System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
            System.out.println("================================================");
            System.out.println("1. Create Rescue Case");
            System.out.println("2. Search Rescue Case");
            System.out.println("3. Update Rescue Status");
            System.out.println("4. Display All Rescue Cases");
            System.out.println("5. Rescue Report");
            System.out.println("6. Exit");
            System.out.print("\nSelect an option: ");

            String option = scanner.nextLine().trim();
            
 //EVALUATES AND ROUTES USER INPUT TO THE CORRECT SYSTEM WORKFLOW MODULE
            switch (option) {
                case "1": createRescueCase(); break;
                case "2": searchRescueCase(); break;
                case "3": updateRescueStatusWorkflow(); break;
                case "4": displayAllCases(); break;
                case "5": generateReport(); break;
                case "6": 
                    System.out.println("Exiting system. Goodbye!"); 
                    return;
                default: 
                    System.out.println("Invalid selection!");
            }
        }
    }
// CREATION WORKFLOW: PROMPTS FOR DATA AND CREATES A NEW RESCUE CASE OBJECT
    private static void createRescueCase() {
        System.out.print("Enter Rescue Case ID: ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty() || isDuplicateId(id)) {
            System.out.println("Error: Case ID cannot be blank and must be unique.");
            return;
        }

        System.out.print("Enter Animal Name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter Species: ");
        String species = scanner.nextLine().trim();
        System.out.print("Enter Rescue Location: ");
        String location = scanner.nextLine().trim();
        System.out.print("Enter Assigned Ranger: ");
        String ranger = scanner.nextLine().trim();

        try {
            System.out.print("Enter Number of Rescue Days: ");
            int days = Integer.parseInt(scanner.nextLine().trim());
            System.out.print("Enter Daily Care Cost: ");
            double dailyCost = Double.parseDouble(scanner.nextLine().trim());

            System.out.println("\nSelect Rescue Type:\n1. Injured Animal\n2. Orphaned Animal\n3. Endangered Species");
            System.out.print("Choice: ");
            String typeChoice = scanner.nextLine().trim();

            if (typeChoice.equals("1")) {
                System.out.print("Injury Description: ");
    String injury = scanner.nextLine().trim();
    System.out.print("Vet Cost: ");double vetCost = Double.parseDouble(scanner.nextLine().trim());
    System.out.print("Surgery Required (true/false): ");boolean surgery = Boolean.parseBoolean(scanner.nextLine().trim());
    cases.add(new InjuredRescue(id, name, species, location, ranger, days, dailyCost, "New Case Logged", injury, vetCost, surgery));} 
      else if 
              (typeChoice.equals("2"))
      {System.out.print("Age (Months): ");int age = Integer.parseInt(scanner.nextLine().trim());
      System.out.print("Feeding Cost: ");double feeding = Double.parseDouble(scanner.nextLine().trim());
      System.out.print("Foster Required (true/false): ");
      boolean 
              foster = Boolean.parseBoolean(scanner.nextLine().trim());
      cases.add(new OrphanedRescue(id, name, species, location, ranger, days, dailyCost, "New Case Logged", age, feeding, foster));} 
      else if 
              (typeChoice.equals("3")) 
      {System.out.print("Conservation Classification: ");String classification = scanner.nextLine().trim();
      System.out.print("Security Cost: ");double security = Double.parseDouble(scanner.nextLine().trim());
      System.out.print("Specialist Required (true/false): ");
      boolean
              spec = Boolean.parseBoolean(scanner.nextLine().trim());
      cases.add(new EndangeredRescue(id, name, species, location, ranger, days, dailyCost, "New Case Logged", classification, security, spec));
      }System.out.println("Rescue case created successfully!");}
        catch (Exception e) {System.out.println("Error: Invalid numeric formatting.");}}
    
    private static void searchRescueCase() {
        
        System.out.print("Enter Rescue Case ID to search: ");String id = scanner.nextLine().trim();
        RescueCase c = findCaseById(id);if (c != null) {generateSummary(c);} 
        else 
        {System.out.println("Case not found.");}}
    
    private static void updateRescueStatusWorkflow() 
    
    {System.out.print("Enter Rescue Case ID: ");String id = scanner.nextLine().trim();
    RescueCase c = findCaseById(id);if (c == null) 
    {System.out.println("Case not found."); return; }
     System.out.println("\n1. Start rescue (Updates to 'Rescue in Progress')");
     System.out.println("2. Complete rescue (Updates to 'Completed & Released')"); 
     System.out.print("Choice: ");String choice = scanner.nextLine().trim();
     if 
             (choice.equals("1")) c.setCurrentStatus("Rescue in Progress");
     else if (choice.equals("2")) c.setCurrentStatus("Completed & Released");
     System.out.println("Status updated successfully.");}
    
    private static void displayAllCases() {
    if (cases.isEmpty()) { System.out.println("No records found."); 
    return; }
    for (RescueCase c : cases) 
    {System.out.println("ID: " + c.getCaseId() + " | " + c.getSpecies() + " (" + c.getAnimalName() + ") | Status: " + c.getCurrentStatus());}}
    
    
    //SYSTEM REPORT: PRINTS A COMPLETE, FIELD-COMPLIANT PROFILE SUMMARY
    private static void generateSummary(RescueCase c) {
     System.out.println("\n--- RESCUE SUMMARY ---");
     System.out.println("Rescue Case ID : " + c.getCaseId());
     System.out.println("Rescue Type    : " + c.getRescueType());
     System.out.println("Species        : " + c.getSpecies());
     System.out.println("Assigned Ranger: " + c.getAssignedRanger());
     System.out.println("Rescue Priority: " + c.determinePriority());
     System.out.println("Current Status : " + c.getCurrentStatus());
     System.out.printf("Total Rescue Cost: R%,.2f\n", c.calculateTotalCost());
     System.out.println("--- Specific Subclass Information ---");c.displaySpecificInfo();}
    
    
    //SYSTEM REORT: COMPILES A TOTAL MANAGEMENT REPORT FOR ALL ACTIVE CASES.
    
    private static void generateReport() {
     System.out.println("\n=================================================");
     System.out.println("WILDLIFE RESCUE REPORT");
     System.out.println("=================================================");
     double runningTotalCost = 0;
     for (RescueCase c : cases)
     {double individualCost = c.calculateTotalCost();runningTotalCost += individualCost;
     System.out.printf("Case ID      : %s\n", c.getCaseId());System.out.printf("Type         : %s\n", c.getRescueType());
     System.out.printf("Species      : %s\n", c.getSpecies());System.out.printf("Priority     : %s\n", c.determinePriority());
     System.out.printf("Status       : %s\n", c.getCurrentStatus());System.out.printf("Total Cost   : R%,.2f\n", individualCost);
     System.out.println("-------------------------------------------------");}System.out.printf("Total Rescue Cases : %d\n", cases.size());
     System.out.printf("Total Rescue Cost  : R%,.2f\n", runningTotalCost);
     System.out.println("=================================================");}
    
    public static boolean isDuplicateId(String id) { 
        return findCaseById(id) != null; }
    
    public static void clearCasesForTesting() { cases.clear(); }
    
    public static void addCaseForTesting(RescueCase c) { cases.add(c); }
    public static RescueCase findCaseById(String id) 
       {for (RescueCase c : cases) {if (c.getCaseId().equalsIgnoreCase(id)) return c;}return null;
    }
}