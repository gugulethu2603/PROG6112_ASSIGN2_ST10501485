/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author 50324
 */
public class WildlifeRescueSystemTest {
    
    public WildlifeRescueSystemTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class WildlifeRescueSystem.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        WildlifeRescueSystem.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isDuplicateId method, of class WildlifeRescueSystem.
     */
    @Test
    public void testIsDuplicateId() {
        System.out.println("isDuplicateId");
        String id = "";
        boolean expResult = false;
        boolean result = WildlifeRescueSystem.isDuplicateId(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of clearCasesForTesting method, of class WildlifeRescueSystem.
     */
    @Test
    public void testClearCasesForTesting() {
        System.out.println("clearCasesForTesting");
        WildlifeRescueSystem.clearCasesForTesting();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addCaseForTesting method, of class WildlifeRescueSystem.
     */
    @Test
    public void testAddCaseForTesting() {
        System.out.println("addCaseForTesting");
        RescueCase c = null;
        WildlifeRescueSystem.addCaseForTesting(c);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findCaseById method, of class WildlifeRescueSystem.
     */
    @Test
    public void testFindCaseById() {
        System.out.println("findCaseById");
        String id = "";
        RescueCase expResult = null;
        RescueCase result = WildlifeRescueSystem.findCaseById(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
