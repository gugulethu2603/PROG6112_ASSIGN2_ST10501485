/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author 50324
 */
public class EndangeredRescueTest {
    
    public EndangeredRescueTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of calculateTotalCost method, of class EndangeredRescue.
     */
    @Test
    public void testCalculateTotalCost() {
        System.out.println("calculateTotalCost");
        EndangeredRescue instance = null;
        double expResult = 0.0;
        double result = instance.calculateTotalCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of determinePriority method, of class EndangeredRescue.
     */
    @Test
    public void testDeterminePriority() {
        System.out.println("determinePriority");
        EndangeredRescue instance = null;
        String expResult = "";
        String result = instance.determinePriority();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueType method, of class EndangeredRescue.
     */
    @Test
    public void testGetRescueType() {
        System.out.println("getRescueType");
        EndangeredRescue instance = null;
        String expResult = "";
        String result = instance.getRescueType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displaySpecificInfo method, of class EndangeredRescue.
     */
    @Test
    public void testDisplaySpecificInfo() {
        System.out.println("displaySpecificInfo");
        EndangeredRescue instance = null;
        instance.displaySpecificInfo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
